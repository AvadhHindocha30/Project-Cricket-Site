import pyttsx3

def speak_commentary(commentary_line):
    engine = pyttsx3.init()
    engine.setProperty('rate', 180)  # Speed of speech
    engine.setProperty('volume', 1.0)  # Max volume

    # Optional: change voice (0 = male, 1 = female, etc.)
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)  # Try voices[0] or voices[1]

    engine.say(commentary_line)
    engine.runAndWait()

# Example usage

engine = pyttsx3.init()
engine.setProperty('rate', 180)  # Speed of speech
engine.setProperty('volume', 1.0)  # Max volume
# Optional: change voice (0 = male, 1 = female, etc.)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)  # Try voices[0] or voices[1]

engine.save_to_file("Taps it into the gap and scampers through for one.", "oneRunCommentary[0].mp3")
engine.save_to_file("Easy single to rotate the strike.", "oneRunCommentary[1].mp3")
engine.save_to_file("Soft hands, and they sneak a quick one.", "oneRunCommentary[2].mp3")
engine.save_to_file("Keeps the scoreboard ticking with a simple run.", "oneRunCommentary[3].mp3")
engine.save_to_file("Pushes to mid-on and jogs across for a single.", "oneRunCommentary[4].mp3")


engine.save_to_file("Nicely placed, they come back for a comfortable two.", "twoRunCommentary[0].mp3")
engine.save_to_file("Good running between the wickets, picks up a couple.", "twoRunCommentary[1].mp3")
engine.save_to_file("Worked into the gap, easy two runs.", "twoRunCommentary[2].mp3")
engine.save_to_file("Turns it away neatly and races back for two.", "twoRunCommentary[3].mp3")
engine.save_to_file("Quick legs - they steal two runs there!", "twoRunCommentary[4].mp3")


engine.save_to_file("Good placement and even better running - three runs added.", "threeRunCommentary[0].mp3")
engine.save_to_file("Chased down near the rope, they take three.", "threeRunCommentary[1].mp3")
engine.save_to_file("Lovely timing, they'll pick up a quick three.", "threeRunCommentary[2].mp3")
engine.save_to_file("They push hard and come back for the third!", "threeRunCommentary[3].mp3")
engine.save_to_file("Three valuable runs - excellent fitness on display.", "threeRunCommentary[4].mp3")

engine.setProperty('rate', 200)

engine.save_to_file("Timed to perfection - that's four!", "fourRunCommentary[0].mp3")
engine.save_to_file("Crashes it through the infield - boundary!", "fourRunCommentary[1].mp3")
engine.save_to_file("Glorious shot, races away for four runs.", "fourRunCommentary[2].mp3")
engine.save_to_file("Threaded the gap beautifully - four more.", "fourRunCommentary[3].mp3")
engine.save_to_file("A gentle push and it speeds away to the fence!", "fourRunCommentary[4].mp3")

engine.setProperty('rate', 220)

engine.save_to_file("That's a massive hit - straight into the stands!", "sixRunCommentary[0].mp3")
engine.save_to_file("Clears the ropes comfortably - six runs!", "sixRunCommentary[1].mp3")
engine.save_to_file("What a strike - the ball sails over long-on!", "sixRunCommentary[2].mp3")
engine.save_to_file("That's gone high and handsome for six!", "sixRunCommentary[3].mp3")
engine.save_to_file("A brutal hit - and it's a clean six!", "sixRunCommentary[4].mp3")

engine.setProperty('rate', 160)
engine.save_to_file("Straight to the fielder - no run.", "dotBallCommentary[0].mp3")
engine.save_to_file("Dot ball - building pressure here.", "dotBallCommentary[1].mp3")
engine.save_to_file("Good tight bowling, no run scored.", "dotBallCommentary[2].mp3")
engine.save_to_file("Batter can't find the gap, dot ball.", "dotBallCommentary[3].mp3")
engine.save_to_file("Defended solidly - nothing off it.", "dotBallCommentary[4].mp3")

engine.setProperty('rate', 220)
engine.save_to_file("Clean bowled! The stumps are shattered!", "bowledCommentary[0].mp3")
engine.save_to_file("Through the gate! What a delivery!", "bowledCommentary[1].mp3")
engine.save_to_file("The batter completely missed it - bowled!", "bowledCommentary[2].mp3")
engine.save_to_file("Top of off-stump, absolute beauty!", "bowledCommentary[3].mp3")
engine.save_to_file("Castled! Timber everywhere!", "bowledCommentary[4].mp3")


engine.setProperty('rate', 180)
engine.save_to_file("Wide down the leg side - extra run.", "wideCommentary[0].mp3")
engine.save_to_file("Strays outside off - wide called.", "wideCommentary[1].mp3")
engine.save_to_file("Bowler loses his line - wide ball.", "wideCommentary[2].mp3")
engine.save_to_file("Umpire stretches the arms - it's a wide!", "wideCommentary[3].mp3")
engine.save_to_file("Too far outside - wide signaled.", "wideCommentary[4].mp3")
engine.setProperty('rate', 200)

engine.save_to_file("Given LBW! Plumb in front!", "lbwCommentary[0].mp3")
engine.save_to_file("Trapped on the pads - up goes the finger!", "lbwCommentary[1].mp3")
engine.save_to_file("No hesitation from the umpire - that's LBW!", "lbwCommentary[2].mp3")
engine.save_to_file("Dead straight, no bat involved - out LBW!", "lbwCommentary[3].mp3")
engine.save_to_file("Hit right in front - batter has to go!", "lbwCommentary[4].mp3")

engine.setProperty('rate', 200)
engine.save_to_file("Caught! Sharp reflexes from the fielder.", "caughtCommentary[0].mp3")
engine.save_to_file("Takes it cleanly at slip - out!", "caughtCommentary[1].mp3")
engine.save_to_file("Soft dismissal - straight to the fielder.", "caughtCommentary[2].mp3")
engine.save_to_file("Caught in the deep! Excellent running catch!", "caughtCommentary[3].mp3")
engine.save_to_file("Pouched safely - batter walks back disappointed.", "caughtCommentary[4].mp3")

engine.setProperty('rate', 190)
engine.save_to_file("Overstepped! No ball signaled.", "noBallCommentary[0].mp3")
engine.save_to_file("Free hit coming up after that no ball!", "noBallCommentary[1].mp3")
engine.save_to_file("Big front foot error - no ball!", "noBallCommentary[2].mp3")
engine.save_to_file("Oh dear! It's a no ball!", "noBallCommentary[3].mp3")
engine.save_to_file("Costly mistake - extra run awarded!", "noBallCommentary[4].mp3")




engine.runAndWait()
